import React from 'react';
import styled from 'styled-components';

const Section = styled.section`
  background: white;
  height:245px;
  display: block;
  background-repeat: no-repeat;
  background-size: contain;
  align-items: center;
`;

const Content = styled.div`
  
  height: 210px;
  display: flex;
  align-items: center;
`;

const Left = styled.div`
  padding-left: 220px;
  padding-top: 20px;
`;

const Right = styled.div`
  padding-left: 220px;
  padding-top: 20px;
  align
  `;

const Title = styled.div`
  font-size: 25px;
  color: #04050b;
  font-weight: 400;
  
`;

const Button = styled.a`
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 18px;
  margin-top: 10px;
  width: 371px;
  height: 68px;
  line-height: 71px;
  font-size: 22px;
  text-align: center;
  color: #fff;
  cursor: pointer;
  background: green;
  text-decoration: none;
  box-shadow: 0 15px 14px rgb(0 42 177 / 12%);
`;

const Text = styled.div`
  padding-top: 5px;
  padding-left: 10px;
  position: relative;
`;
const Textbox = styled.div`
  width: 220px;
  height: 36px;
  position: relative;
  box-sizing: border-box;
  background: rgba(179, 191, 201, 0.15);
  line-height: 33px;
  padding-left: 37px;
  border-radius: 19px;
  margin: 10px;
`;

const Input = styled.input`
  color: #000;
  width: 196px;
  border: transparent;
  font-size: 12px;
  background: transparent;
  outline: none;

  &::placeholder {
    color: #d1d8de;
  }
`;

const Hero = () => {
  return (
    <Section>
      <Content>
        <Left>
          <Title>
           New? Create an account here!
          </Title>
          <Text>
           <Textbox>
             <Input type='text' placeholder='username'/>
          </Textbox>
          <div>

          </div>
          <Textbox>
             <Input type='text' placeholder='password'/>
          </Textbox>
          </Text>
          <Button>
            SIGN UP
          </Button>
        </Left>
        <Right>
        <Title>
           Already a user? Login here!
          </Title>
          <Text>
           <Textbox>
             <Input type='text' placeholder='username'/>
          </Textbox>
          <Textbox>
             <Input type='text' placeholder='password'/>
          </Textbox>
          </Text>
        <Button>LOG IN</Button>
        </Right>
      </Content>
    </Section>
  );
};

export default Hero;
